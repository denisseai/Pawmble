package com.example.walkingbuddiesdogedition.util

val DATA_USERS = "Users"